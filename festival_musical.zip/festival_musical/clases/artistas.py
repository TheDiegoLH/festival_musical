class Artista:
    generos_permitidos = ["Pop", "Rock", "Electrónica", "House", "Techno", "Dubstep"]

    def __init__(self, nombre, genero, popularidad):
        self.nombre = nombre
        self.genero = genero
        self.popularidad = popularidad

        if not Artista.validar_genero(genero):
            raise ValueError(f"Género '{genero}' no permitido.")
        if not Artista.validar_popularidad(popularidad):
            raise ValueError("La popularidad debe estar entre 1 y 100.")

        print(f"🎶 Bienvenido {self.nombre} al festival 🎶")

    def presentarse(self):
        print(f"Hola, soy {self.nombre}, interpreto {self.genero} y mi popularidad es {self.popularidad}/100.")

    def actuar(self):
        raise NotImplementedError("Este método debe ser sobrescrito por las clases derivadas.")

    def despedirse(self):
        print(f"{self.nombre} agradece al público y se despide 👋")

    def mostrar_info(self):
        print(f"Nombre: {self.nombre}, Género: {self.genero}, Popularidad: {self.popularidad}")

    @staticmethod
    def validar_genero(genero):
        return genero in Artista.generos_permitidos

    @staticmethod
    def validar_popularidad(popularidad):
        return 1 <= popularidad <= 100


class Cantante(Artista):
    def __init__(self, nombre, genero, popularidad, cancion_mas_popular):
        super().__init__(nombre, genero, popularidad)
        self.cancion_mas_popular = cancion_mas_popular

    def presentarse(self):
        super().presentarse()
        print("¡Prepárense para cantar!")

    def actuar(self):
        print(f"🎤 {self.nombre} canta su éxito '{self.cancion_mas_popular}' con gran energía.")


class DJ(Artista):
    def __init__(self, nombre, genero, popularidad, estilo):
        super().__init__(nombre, genero, popularidad)
        self.estilo = estilo

    def presentarse(self):
        super().presentarse()
        print("¡Que empiece la fiesta!")

    def actuar(self):
        print(f"🎧 El DJ {self.nombre} mezcla temas de estilo {self.estilo}, haciendo vibrar al público.")


class Banda(Artista):
    def __init__(self, nombre, genero, popularidad, integrantes):
        super().__init__(nombre, genero, popularidad)
        if integrantes <= 0:
            raise ValueError("El número de integrantes debe ser positivo.")
        self.integrantes = integrantes

    def presentarse(self):
        super().presentarse()
        print("¡Somos una banda en vivo!")

    def actuar(self):
        print(f"🎸 La banda {self.nombre} con {self.integrantes} integrantes toca un poderoso solo de guitarra.")
