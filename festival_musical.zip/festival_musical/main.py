from clases.artistas import Cantante, DJ, Banda

def iniciar_festival(lista_artistas):
    print("🎤 ¡BIENVENIDOS AL FESTIVAL! 🎶")
    print("~" * 50)
    for artista in lista_artistas:
        artista.presentarse()
        artista.actuar()
        artista.despedirse()
        print("🎉 Fin de la actuación 🎉")
        print("~" * 50)


def main():
    lista_artistas = []
    cantidad = int(input("¿Cuántos artistas se presentarán en el festival? "))

    for i in range(cantidad):
        print(f"\n--- Registro del artista {i+1} ---")
        tipo = input("Tipo de artista (Cantante/DJ/Banda): ").strip()
        nombre = input("Nombre: ").strip()
        genero = input("Género musical: ").strip()
        popularidad = int(input("Popularidad (1-100): "))

        try:
            if tipo.lower() == "cantante":
                cancion = input("Canción más popular: ").strip()
                artista = Cantante(nombre, genero, popularidad, cancion)

            elif tipo.lower() == "dj":
                estilo = input("Estilo del DJ (House, Techno, Dubstep, etc.): ").strip()
                artista = DJ(nombre, genero, popularidad, estilo)

            elif tipo.lower() == "banda":
                integrantes = int(input("Número de integrantes: "))
                artista = Banda(nombre, genero, popularidad, integrantes)

            else:
                print("❌ Tipo de artista no válido.")
                continue

            lista_artistas.append(artista)

        except ValueError as e:
            print(f"Error: {e}")

    iniciar_festival(lista_artistas)


if __name__ == "__main__":
    main()
